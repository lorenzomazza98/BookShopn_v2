package bookshopparthenope;

import bookshopparthenope.Model.UserManagement.Admin;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

import java.io.IOException;

public class AdminPanelController {

    @FXML
    private Button inserisciLibroButton;
    private Parent root;

    @FXML
    void switchToInsert(ActionEvent event)  throws IOException {
        FxmlController controller=new FxmlController();
        controller.openInsert(root,inserisciLibroButton);
    }

    FxmlController control =new FxmlController();
    @FXML
    private Button logoutButton;


    @FXML
    void logout(ActionEvent event) throws IOException {
        control.logout(root,logoutButton);
    }
}

