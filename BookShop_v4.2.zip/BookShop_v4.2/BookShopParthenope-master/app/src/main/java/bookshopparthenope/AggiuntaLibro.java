package bookshopparthenope;

import bookshopparthenope.Model.UserManagement.DBService;
import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.DragEvent;
import javafx.stage.Stage;

import javax.swing.*;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class AggiuntaLibro implements Initializable{
  @FXML
  private TextField anno;

  @FXML
  private Button annulla;

  @FXML
  private TextField autore;


  @FXML
  private TextField descrizione;

  @FXML
  private Button inserisciLibroButton;

  @FXML
  private TextField isbn;

  @FXML
  private TextField pagine;

  @FXML
  private TextField prezzo;

  @FXML
  private TextField quantita;



  @FXML
  private TextField titolo;





  @FXML
  void insertBook(ActionEvent event) throws SQLException, ClassNotFoundException {

    String cat="categoria";
    String scat="sottocategoria";
    int quantita_int = Integer.parseInt(quantita.getText());
    int prezzo_int = Integer.parseInt(prezzo.getText());
    DBService.insertBook(titolo.getText(),autore.getText(),anno.getText(),pagine.getText(),quantita_int,cat,scat,isbn.getText(),prezzo_int);
  }



  @FXML
  public void cancel(ActionEvent event) {
    Stage stage = (Stage) annulla.getScene().getWindow();
    stage.close();
  }




  @FXML
  private ComboBox<String> categoria;

  @FXML
  private ComboBox<String> sottocategoria;
  public String categoriaScelta;
  public String sottoCategoriaScelta;
  private String[] categorie = {"Letteratura","Arte e Musica","Biografia","Fumetti","Computer e Tech","Cucina","Educazione","Intrattenomento","Business"};
  @FXML
  public void setSottocategoria(ActionEvent event) {

        System.out.println("gfhvbj");
    }



  @Override
  public void initialize(URL arg0, ResourceBundle arg1) {
    categoria.getItems().addAll(categorie);
    categoria.setOnAction(this::getChoice);


  }

public void getChoice(ActionEvent event) {
    if (sottocategoria.isDisabled()){
      sottocategoria.setDisable(false);
    }
         categoriaScelta = categoria.getValue();
        switch (categoriaScelta){
          case "Letteratura":
            String[] sLetteratura = {"Antologie","Classici","Contemporanei","Lingue Straniere","Letterature"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sLetteratura);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Arte e Musica":
            String[] sArte = {"Storia dell'arte","Calligrafia","Disegno","Fashion Design"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sArte);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Biografia":
            String[] sBiografia = {"Etnica e Culturale","Europea","Storica","Personaggi Famosi e Leader","Militare"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sBiografia);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Fumetti":
            String[] sFumetti = {"Comici","Marvel","Misteriosi","DC","Fantasy"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sFumetti);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Computer e Tech":
            String[] sComputer= {"Apple","CAD","Certificazioni","Informatica","Database"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sComputer);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Cucina":
            String[] sCucina = {"Asiatica","Cucina Calda","BBQ","Arti Culinarie","Dolci"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sCucina);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Educazione":
            String[] sEducazione = {"Almanacchi","Atlanti e Mappe","Cataloghi","Scolastici"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sEducazione);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Intrattenomento":
            String[] sIntrattenomento = {"Rompicapo","Barzellette","Giochi","Film"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sIntrattenomento);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          case "Business":
            String[] sBusiness = {"Carriera","Economia","Finanza","Industria","Internazionale"};
            sottocategoria.getItems().clear();
            sottocategoria.getItems().addAll(sBusiness);
            sottocategoria.setOnAction(this::getChoice2);
            break;
          default:
            System.out.println("error");
            break;
        }


        }

  public void getChoice2(ActionEvent event) {
    sottoCategoriaScelta = sottocategoria.getValue();
  }

}


