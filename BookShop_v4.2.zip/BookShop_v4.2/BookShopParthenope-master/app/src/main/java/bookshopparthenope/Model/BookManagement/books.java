package bookshopparthenope.Model.BookManagement;

//Ora creo classe book e le classi categoria e sottocategoria. Categoria estende libro, mentre sottocategoria estende categoria.

//Classe Padre per libro
abstract class Book {
  protected String subcategory;

  public Book (String subcategory) {
    this.subcategory = subcategory;
  }
  public abstract String getCategory();
}


//Categorie che estendono Book
class LetteraturaBook extends Book {
  public LetteraturaBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Letteratura"; }
}




class ArteemusicaBook extends Book {
  public ArteemusicaBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Arte e Musica"; }
}


class BiografiaBook extends Book {
  public BiografiaBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Biografia"; }
}

class BusinessBook extends Book {
  public BusinessBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Business"; }
}

class FumettiBook extends Book {
  public FumettiBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Fumetti"; }
}

class ComputeretechBook extends Book {
  public ComputeretechBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Computer e Tech"; }
}

class CucinaBook extends Book {
  public CucinaBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Cucina"; }
}

class EducazioneBook extends Book {
  public EducazioneBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Educazione"; }
}

class IntrattenimentoBook extends Book {
  public IntrattenimentoBook(String subcategory) {
    super(subcategory); }
  @Override
  public String getCategory() {
    return "Intrattenimento"; }
}


//Sottocategorie che estendono categorie

class Antologie extends LetteraturaBook {
  public Antologie() {
    super("Antologie");
  }
}

class Classici extends LetteraturaBook{
  public Classici(){
    super("Classici");
  }
}

class Contemporanei extends LetteraturaBook{
  public Contemporanei(){
    super("Contemporanei");
  }
}

class Linguestraniere extends LetteraturaBook{
  public Linguestraniere(){
    super("Lingue Straniere");
  }
}

class Letterature extends LetteraturaBook{
  public Letterature(){
    super("Letterature");
  }
}

class Storiadellarte extends ArteemusicaBook{
  public Storiadellarte(){
    super("Storia dell'arte");
  }
}

class Calligrafia extends ArteemusicaBook{
  public Calligrafia(){
    super("Calligrafia");
  }
}

class Disegno extends ArteemusicaBook{
  public Disegno(){
    super("Disegno");
  }
}

class Fashiondesign extends ArteemusicaBook{
  public Fashiondesign(){
    super("Fashion Design");
  }
}


class Etnicaeculturale extends BiografiaBook{
  public Etnicaeculturale(){
    super("Etnica e Culturale");
  }
}

class Europea extends BiografiaBook{
  public Europea(){
    super("Europea");
  }
}

class Storica extends BiografiaBook{
  public Storica(){
    super("Storica");
  }
}

class Personaggifamosieleader extends BiografiaBook{
  public Personaggifamosieleader(){
    super("Personaggi Famosi e Leader");
  }
}

class Militare extends BiografiaBook{
  public Militare(){
    super("Militare");
  }
}

class Carriera extends BusinessBook{
  public Carriera(){
    super("Carriera");
  }
}

class Economia extends BusinessBook{
  public Economia(){
    super("Economia");
  }
}

class Finanza extends BusinessBook{
  public Finanza(){
    super("Finanza");
  }
}

class Industria extends BusinessBook{
  public Industria(){
    super("Industria");
  }
}

class Internazionale extends BusinessBook{
  public Internazionale(){
    super("Internazionale");
  }
}

class Comici extends FumettiBook{
  public Comici(){
    super("Comici");
  }
}

class Misteriosi extends FumettiBook{
  public Misteriosi(){
    super("Misteriosi");
  }
}

class DC extends FumettiBook{
  public DC(){
    super("DC");
  }
}

class Fantasy extends FumettiBook{
  public Fantasy(){
    super("Fantasy");
  }
}

class Apple extends ComputeretechBook{
  public Apple(){
    super("Apple");
  }
}

class CAD extends ComputeretechBook{
  public CAD(){
    super("CAD");
  }
}

class Certificazioni extends ComputeretechBook{
  public Certificazioni(){
    super("Certificazioni");
  }
}

class Informatica extends ComputeretechBook{
  public Informatica(){
    super("Informatica");
  }
}

class Database extends ComputeretechBook{
  public Database(){
    super("Database");
  }
}

class Asiatica extends CucinaBook{
  public Asiatica(){
    super("Asiatica");
  }
}

class Cucinacalda extends CucinaBook{
  public Cucinacalda(){
    super("Cucina Calda");
  }
}

class BBQ extends CucinaBook{
  public BBQ(){
    super("BBQ");
  }
}

class Articulinarie extends CucinaBook{
  public Articulinarie(){
    super("Arti Culinarie");
  }
}

class Dolci extends CucinaBook{
  public Dolci(){
    super("Dolci");
  }
}

class Almanacchi extends EducazioneBook{
  public Almanacchi(){
    super("Almanacchi");
  }
}

class Atlantiemappe extends EducazioneBook{
  public Atlantiemappe(){
    super("Atlanti e Mappe");
  }
}

class Cataloghi extends EducazioneBook{
  public Cataloghi(){
    super("Cataloghi");
  }
}

class Scolastici extends EducazioneBook{
  public Scolastici(){
    super("Scolastici");
  }
}

class Rompicapo extends IntrattenimentoBook{
  public Rompicapo(){
    super("Rompicapo");
  }
}

class Barzellette extends IntrattenimentoBook{
  public Barzellette(){
    super("Barzellette");
  }
}

class Giochi extends IntrattenimentoBook{
  public Giochi(){
    super("Giochi");
  }
}

class Film extends IntrattenimentoBook{
  public Film(){
    super("Film");
  }
}
