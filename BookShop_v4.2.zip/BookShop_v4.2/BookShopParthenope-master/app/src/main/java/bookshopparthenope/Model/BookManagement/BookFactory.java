package bookshopparthenope.Model.BookManagement;
//PATTERN FACTORY PER CREAZIONE LIBRO
class BookFactory{
  public Book createBook(String category, String subcategory) {
    switch (category.toLowerCase()) {
      case "Letteratura":
        return new LetteraturaBook(subcategory);
      case "Arte e Musica":
        return new ArteemusicaBook(subcategory);
      case "Biografia":
        return new BiografiaBook(subcategory);
      case "Business":
        return new BusinessBook(subcategory);
      case "Fumetti":
        return new FumettiBook(subcategory);
      case "Computer e Tech":
        return new ComputeretechBook(subcategory);
      case "Cucina":
        return new CucinaBook(subcategory);
      case "Educazione":
        return new EducazioneBook(subcategory);
      case "Intrattenimento":
        return new IntrattenimentoBook(subcategory);
      default:
        return null;
    }
  }
}
